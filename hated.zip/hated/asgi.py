"""ASGI config for the hated project."""
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hated.settings')
application = get_asgi_application()
