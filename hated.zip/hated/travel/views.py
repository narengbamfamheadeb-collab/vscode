from django.contrib import messages  # type: ignore[reportMissingImports]
import django.contrib.auth
import django.contrib.auth.decorators
import django.core.paginator
import django.http
from django.shortcuts import get_object_or_404, redirect, render # type: ignore

from . import ai_service
from .forms import (
    ChatMessageForm,
    ItineraryBuilderForm,
    ProfileForm,
    RecommendationForm,
    SignUpForm,
)
from .models import (
    ActivityTag,
    ChatMessage,
    Destination,
    Itinerary,
    ItineraryActivity,
    ItineraryDay,
)


def index(request):
    """Homepage: hero section + a handful of featured destinations."""
    featured = Destination.objects.all()[:6]
    context = {
        'featured_destinations': featured,
        'destination_count': Destination.objects.count(),
    }
    return render(request, 'travel/index.html', context)


# ---------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------

def signup(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            django.contrib.auth.login(request, user)
            messages.success(request, "Welcome! Your account has been created.")
            return redirect('index')
    else:
        form = SignUpForm()
    return render(request, 'travel/signup.html', {'form': form})


# ---------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------

@django.contrib.auth.decorators.login_required
def profile(request):
    user_profile = request.user.profile
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated.")
            return redirect('profile')
    else:
        form = ProfileForm(instance=user_profile)

    recent_itineraries = request.user.itineraries.all()[:5]
    return render(request, 'travel/profile.html', {
        'form': form,
        'recent_itineraries': recent_itineraries,
    })


@django.contrib.auth.decorators.login_required
def toggle_favorite(request, pk):
    destination = get_object_or_404(Destination, pk=pk)
    profile_obj = request.user.profile
    if destination in profile_obj.favorite_destinations.all():
        profile_obj.favorite_destinations.remove(destination)
        messages.info(request, f"Removed {destination.name} from favorites.")
    else:
        profile_obj.favorite_destinations.add(destination)
        messages.success(request, f"Added {destination.name} to favorites.")
    return redirect(request.META.get('HTTP_REFERER', 'destinations'))


# ---------------------------------------------------------------------
# Destination discovery
# ---------------------------------------------------------------------

def destinations(request):
    qs = Destination.objects.all().prefetch_related('activity_tags')

    country = request.GET.get('country', '').strip()
    budget = request.GET.get('budget', '').strip()
    season = request.GET.get('season', '').strip()
    activity = request.GET.get('activity', '').strip()

    if country:
        qs = qs.filter(country__icontains=country)
    if budget:
        qs = qs.filter(budget_level=budget)
    if season:
        qs = qs.filter(best_season=season)
    if activity:
        qs = qs.filter(activity_tags__id=activity)

    paginator = django.core.paginator.Paginator(qs.distinct(), 9)
    page_obj = paginator.get_page(request.GET.get('page'))

    favorite_ids = set()
    if request.user.is_authenticated:
        favorite_ids = set(request.user.profile.favorite_destinations.values_list('id', flat=True))

    return render(request, 'travel/destinations.html', {
        'page_obj': page_obj,
        'all_tags': ActivityTag.objects.all(),
        'filters': {
            'country': country, 'budget': budget, 'season': season, 'activity': activity,
        },
        'favorite_ids': favorite_ids,
    })


def destination_detail(request, pk):
    destination = get_object_or_404(Destination, pk=pk)
    is_favorite = (
        request.user.is_authenticated
        and destination in request.user.profile.favorite_destinations.all()
    )
    return render(request, 'travel/destination_detail.html', {
        'destination': destination,
        'is_favorite': is_favorite,
    })


# ---------------------------------------------------------------------
# AI recommendation engine
# ---------------------------------------------------------------------

@django.contrib.auth.decorators.login_required
def recommend(request):
    result = None
    if request.method == 'POST':
        form = RecommendationForm(request.POST)
        if form.is_valid():
            result = ai_service.generate_recommendations(
                budget=form.cleaned_data['budget'],
                interests=form.cleaned_data['interests'],
                travel_dates=form.cleaned_data['travel_dates'],
                group_size=form.cleaned_data['group_size'],
            )
    else:
        initial = {
            'budget': request.user.profile.preferred_budget,
            'group_size': request.user.profile.preferred_group_size,
        }
        form = RecommendationForm(initial=initial)

    return render(request, 'travel/recommend.html', {'form': form, 'result': result})


# ---------------------------------------------------------------------
# Chat assistant
# ---------------------------------------------------------------------

@django.contrib.auth.decorators.login_required
def chat(request):
    if request.method == 'POST':
        form = ChatMessageForm(request.POST)
        if form.is_valid():
            user_message = form.cleaned_data['message']
            ChatMessage.objects.create(user=request.user, role='user', content=user_message)

            recent_msgs = list(request.user.chat_messages.order_by('-created_at')[:20])
            recent_msgs.reverse()  # back to chronological order for the API
            history = [{'role': m.role, 'content': m.content} for m in recent_msgs]
            reply = ai_service.get_chat_reply(user_message, history=history[:-1])
            ChatMessage.objects.create(user=request.user, role='assistant', content=reply)

            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return django.http.JsonResponse({'reply': reply})
            return redirect('chat')
    else:
        form = ChatMessageForm()

    history = request.user.chat_messages.order_by('created_at')
    return render(request, 'travel/chat.html', {'form': form, 'history': history})


@django.contrib.auth.decorators.login_required
def chat_clear(request):
    if request.method == 'POST':
        request.user.chat_messages.all().delete()
    return redirect('chat')


# ---------------------------------------------------------------------
# Itinerary builder
# ---------------------------------------------------------------------

@django.contrib.auth.decorators.login_required
def my_itineraries(request):
    itineraries = request.user.itineraries.all()
    return render(request, 'travel/my_itineraries.html', {'itineraries': itineraries})


@django.contrib.auth.decorators.login_required
def itinerary_builder(request):
    if request.method == 'POST':
        form = ItineraryBuilderForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            raw_name = data['destination_name'].strip()
            if ',' in raw_name:
                dest_name, dest_country = (part.strip() for part in raw_name.split(',', 1))
            else:
                dest_name, dest_country = raw_name, ''
            destination, _ = Destination.objects.get_or_create(
                name=dest_name,
                defaults={'country': dest_country, 'budget_level': data['budget']},
            )

            itinerary = Itinerary.objects.create(
                user=request.user,
                title=data['title'],
                destination=destination,
                start_date=data['start_date'],
                end_date=data['end_date'],
                budget=data['budget'],
                group_size=data['group_size'],
                is_ai_generated=data['use_ai'],
            )

            if data['use_ai']:
                plan = ai_service.generate_itinerary(
                    destination_name=data['destination_name'],
                    num_days=data['num_days'],
                    budget=data['budget'],
                    interests=data['interests'],
                    group_size=data['group_size'],
                )
                itinerary.notes = plan.get('summary', '')
                itinerary.save()
                for day_data in plan.get('days', []):
                    day = ItineraryDay.objects.create(
                        itinerary=itinerary,
                        day_number=day_data.get('day_number', 1),
                        summary=day_data.get('summary', ''),
                    )
                    for i, act in enumerate(day_data.get('activities', [])):
                        ItineraryActivity.objects.create(
                            day=day,
                            order=i,
                            time=act.get('time', ''),
                            title=act.get('title', ''),
                            description=act.get('description', ''),
                            location=act.get('location', ''),
                        )
            else:
                for d in range(1, data['num_days'] + 1):
                    ItineraryDay.objects.create(itinerary=itinerary, day_number=d)

            messages.success(request, "Itinerary created!")
            return redirect('itinerary_detail', pk=itinerary.pk)
    else:
        initial = {}
        prefill_destination = request.GET.get('destination', '').strip()
        if prefill_destination:
            initial['destination_name'] = prefill_destination
            initial['title'] = f"Trip to {prefill_destination}"
        form = ItineraryBuilderForm(initial=initial)

    return render(request, 'travel/itinerary_builder.html', {'form': form})


@django.contrib.auth.decorators.login_required
def itinerary_detail(request, pk):
    itinerary = get_object_or_404(Itinerary, pk=pk, user=request.user)
    return render(request, 'travel/itinerary_detail.html', {'itinerary': itinerary})


@django.contrib.auth.decorators.login_required
def itinerary_delete(request, pk):
    itinerary = get_object_or_404(Itinerary, pk=pk, user=request.user)
    if request.method == 'POST':
        itinerary.delete()
        messages.info(request, "Itinerary deleted.")
        return redirect('my_itineraries')
    return render(request, 'travel/itinerary_confirm_delete.html', {'itinerary': itinerary})


@django.contrib.auth.decorators.login_required
def add_day_activity(request, day_id):
    day = get_object_or_404(ItineraryDay, pk=day_id, itinerary__user=request.user)
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        if title:
            ItineraryActivity.objects.create(
                day=day,
                order=day.activities.count(),
                time=request.POST.get('time', '').strip(),
                title=title,
                description=request.POST.get('description', '').strip(),
                location=request.POST.get('location', '').strip(),
            )
    return redirect('itinerary_detail', pk=day.itinerary.pk)
