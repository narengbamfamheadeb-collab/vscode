// Auto-scroll the chat window to the latest message on load.
document.addEventListener('DOMContentLoaded', function () {
    var chatWindow = document.getElementById('chatWindow');
    if (chatWindow) {
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }
});
