from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),

    # Auth
    path('signup/', views.signup, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='travel/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Profile
    path('profile/', views.profile, name='profile'),
    path('favorite/<int:pk>/', views.toggle_favorite, name='toggle_favorite'),

    # Discovery
    path('destinations/', views.destinations, name='destinations'),
    path('destinations/<int:pk>/', views.destination_detail, name='destination_detail'),

    # AI recommendations & chat
    path('recommend/', views.recommend, name='recommend'),
    path('chat/', views.chat, name='chat'),
    path('chat/clear/', views.chat_clear, name='chat_clear'),

    # Itinerary builder
    path('itineraries/', views.my_itineraries, name='my_itineraries'),
    path('itineraries/new/', views.itinerary_builder, name='itinerary_builder'),
    path('itineraries/<int:pk>/', views.itinerary_detail, name='itinerary_detail'),
    path('itineraries/<int:pk>/delete/', views.itinerary_delete, name='itinerary_delete'),
    path('itineraries/day/<int:day_id>/add-activity/', views.add_day_activity, name='add_day_activity'),
]
