from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse


BUDGET_CHOICES = [
    ('budget', 'Budget'),
    ('mid', 'Mid-range'),
    ('luxury', 'Luxury'),
]

SEASON_CHOICES = [
    ('spring', 'Spring'),
    ('summer', 'Summer'),
    ('autumn', 'Autumn'),
    ('winter', 'Winter'),
    ('any', 'Any season'),
]


class ActivityTag(models.Model):
    """A short tag describing an activity type, e.g. 'Hiking', 'Nightlife'."""
    name = models.CharField(max_length=50, unique=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class Destination(models.Model):
    """A place tourists can discover, filter, and build itineraries for."""
    name = models.CharField(max_length=120)
    country = models.CharField(max_length=80)
    description = models.TextField(blank=True)
    image_url = models.URLField(blank=True, help_text="Link to a representative photo.")
    budget_level = models.CharField(max_length=10, choices=BUDGET_CHOICES, default='mid')
    best_season = models.CharField(max_length=10, choices=SEASON_CHOICES, default='any')
    avg_cost_per_day = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    activity_tags = models.ManyToManyField(ActivityTag, blank=True, related_name='destinations')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.name}, {self.country}"

    def get_absolute_url(self):
        return reverse('destination_detail', args=[self.pk])


class UserProfile(models.Model):
    """Extra travel-related preferences attached one-to-one to a User."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(blank=True)
    home_city = models.CharField(max_length=100, blank=True)
    preferred_budget = models.CharField(max_length=10, choices=BUDGET_CHOICES, default='mid')
    preferred_group_size = models.PositiveIntegerField(default=1)
    interests = models.ManyToManyField(ActivityTag, blank=True, related_name='interested_users')
    favorite_destinations = models.ManyToManyField(Destination, blank=True, related_name='favorited_by')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Profile of {self.user.username}"


class Itinerary(models.Model):
    """A trip plan, either hand-built or AI-generated, owned by a user."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='itineraries')
    title = models.CharField(max_length=150)
    destination = models.ForeignKey(
        Destination, on_delete=models.SET_NULL, null=True, blank=True, related_name='itineraries'
    )
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    budget = models.CharField(max_length=10, choices=BUDGET_CHOICES, default='mid')
    group_size = models.PositiveIntegerField(default=1)
    notes = models.TextField(blank=True)
    is_ai_generated = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = 'itineraries'

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('itinerary_detail', args=[self.pk])

    @property
    def duration_days(self):
        if self.start_date and self.end_date:
            return (self.end_date - self.start_date).days + 1
        return self.days.count()


class ItineraryDay(models.Model):
    """A single day within an itinerary."""
    itinerary = models.ForeignKey(Itinerary, on_delete=models.CASCADE, related_name='days')
    day_number = models.PositiveIntegerField()
    date = models.DateField(null=True, blank=True)
    summary = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ['day_number']
        unique_together = ('itinerary', 'day_number')

    def __str__(self):
        return f"{self.itinerary.title} — Day {self.day_number}"


class ItineraryActivity(models.Model):
    """A single planned activity/stop within a day."""
    day = models.ForeignKey(ItineraryDay, on_delete=models.CASCADE, related_name='activities')
    order = models.PositiveIntegerField(default=0)
    time = models.CharField(max_length=40, blank=True, help_text="e.g. '9:00 AM' or 'Morning'")
    title = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    location = models.CharField(max_length=150, blank=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.title


class ChatMessage(models.Model):
    """One message in a user's ongoing conversation with the AI travel assistant."""
    ROLE_CHOICES = [('user', 'User'), ('assistant', 'Assistant')]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chat_messages')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"[{self.role}] {self.content[:40]}"
