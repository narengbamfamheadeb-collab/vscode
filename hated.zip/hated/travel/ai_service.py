"""
AI integration layer for the travel partner app.

Wraps calls to the Anthropic (Claude) API for two features:
  1. Free-form travel chat (get_chat_reply)
  2. Structured itinerary / recommendation generation (generate_itinerary)

If ANTHROPIC_API_KEY is not configured, both functions fall back to
simple canned responses so the rest of the site keeps working while
you develop locally or demo without a key.

Install the official SDK with:  pip install anthropic
"""
import json
import logging

from django.conf import settings

logger = logging.getLogger(__name__)

try:
    import anthropic  # type: ignore
    _SDK_AVAILABLE = True
except ImportError:
    _SDK_AVAILABLE = False


def _client():
    if not _SDK_AVAILABLE or not settings.ANTHROPIC_API_KEY:
        return None
    return anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)


def _ai_enabled():
    return _SDK_AVAILABLE and bool(settings.ANTHROPIC_API_KEY)


SYSTEM_PROMPT = (
    "You are Voyagent, a friendly, knowledgeable AI travel assistant embedded "
    "in a travel-planning website. Give concise, practical, well-organized "
    "advice: destinations, budgets, itineraries, local tips, safety notes. "
    "Use short paragraphs or bullet points. Keep replies under ~200 words "
    "unless the user is asking for a full itinerary."
)


def get_chat_reply(message, history=None):
    """
    Get a conversational reply for the chat assistant page.

    `history` is an optional list of {"role": "user"|"assistant", "content": str}
    dicts representing prior turns, oldest first.
    """
    history = history or []

    if not _ai_enabled():
        return (
            "(Demo mode — no ANTHROPIC_API_KEY configured yet.) "
            "Once you add your API key in settings, I'll give you real "
            f"AI-powered travel advice. For now, here's a placeholder reply "
            f"to: \u201c{message}\u201d"
        )

    try:
        client = _client()
        messages = history + [{"role": "user", "content": message}]
        response = client.messages.create(
            model=settings.ANTHROPIC_MODEL,
            max_tokens=800,
            system=SYSTEM_PROMPT,
            messages=messages,
        )
        return "".join(
            block.text for block in response.content if getattr(block, "type", "") == "text"
        ).strip()
    except Exception:
        logger.exception("Claude chat request failed")
        return "Sorry, I couldn't reach the AI service just now. Please try again in a moment."


ITINERARY_SYSTEM_PROMPT = (
    "You are a travel-planning assistant. You must respond with ONLY valid "
    "JSON — no markdown fences, no commentary before or after. The JSON "
    "schema is:\n"
    "{\n"
    '  "summary": "1-2 sentence trip overview",\n'
    '  "days": [\n'
    "    {\n"
    '      "day_number": 1,\n'
    '      "summary": "short theme for the day",\n'
    '      "activities": [\n'
    '        {"time": "Morning", "title": "...", "description": "...", "location": "..."}\n'
    "      ]\n"
    "    }\n"
    "  ]\n"
    "}"
)


def _mock_itinerary(destination_name, num_days, interests):
    """Deterministic offline fallback so the itinerary builder always works."""
    days = []
    for d in range(1, num_days + 1):
        days.append({
            "day_number": d,
            "summary": f"Explore {destination_name} — day {d}",
            "activities": [
                {
                    "time": "Morning",
                    "title": f"Visit a top {destination_name} landmark",
                    "description": "Add your own details, or connect an API key for AI-generated plans.",
                    "location": destination_name,
                },
                {
                    "time": "Afternoon",
                    "title": "Local food & culture",
                    "description": f"Sample local cuisine and, if it fits, {interests or 'local activities'}.",
                    "location": destination_name,
                },
                {
                    "time": "Evening",
                    "title": "Relax and unwind",
                    "description": "Free time — explore a nearby neighborhood or rest up for tomorrow.",
                    "location": destination_name,
                },
            ],
        })
    return {
        "summary": (
            f"(Demo mode) A {num_days}-day starter plan for {destination_name}. "
            "Configure ANTHROPIC_API_KEY for a fully AI-personalized itinerary."
        ),
        "days": days,
    }


def generate_itinerary(destination_name, num_days, budget, interests, group_size):
    """
    Ask Claude for a structured day-by-day itinerary.
    Returns a dict matching ITINERARY_SYSTEM_PROMPT's schema.
    Falls back to a mock itinerary if the AI is unavailable or the
    response can't be parsed as JSON.
    """
    if not _ai_enabled():
        return _mock_itinerary(destination_name, num_days, interests)

    user_prompt = (
        f"Plan a {num_days}-day trip to {destination_name}.\n"
        f"Budget level: {budget}.\n"
        f"Group size: {group_size}.\n"
        f"Interests: {interests or 'general sightseeing'}.\n"
        "Return only the JSON described in your instructions."
    )

    try:
        client = _client()
        response = client.messages.create(
            model=settings.ANTHROPIC_MODEL,
            max_tokens=2000,
            system=ITINERARY_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}],
        )
        text = "".join(
            block.text for block in response.content if getattr(block, "type", "") == "text"
        ).strip()
        text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data = json.loads(text)
        if "days" not in data:
            raise ValueError("Missing 'days' key in AI response")
        return data
    except Exception:
        logger.exception("Claude itinerary generation failed; using fallback")
        return _mock_itinerary(destination_name, num_days, interests)


def generate_recommendations(budget, interests, travel_dates, group_size):
    """
    Ask Claude for 3-5 destination recommendations as short text.
    Returns plain text (rendered as markdown-ish bullets in the template).
    """
    if not _ai_enabled():
        return (
            "(Demo mode — no ANTHROPIC_API_KEY configured.) Here are generic "
            "starter picks: Lisbon, Portugal (budget-friendly, great food); "
            "Kyoto, Japan (culture, temples); Costa Rica (adventure & nature). "
            "Add your API key for personalized, AI-generated picks."
        )

    prompt = (
        "Suggest 3-5 travel destinations for a trip with these preferences:\n"
        f"- Budget: {budget}\n"
        f"- Interests: {interests or 'open to anything'}\n"
        f"- Travel dates / season: {travel_dates or 'flexible'}\n"
        f"- Group size: {group_size}\n\n"
        "For each, give the destination name and 1-2 sentences on why it fits. "
        "Format as a simple bulleted list."
    )

    try:
        client = _client()
        response = client.messages.create(
            model=settings.ANTHROPIC_MODEL,
            max_tokens=600,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(
            block.text for block in response.content if getattr(block, "type", "") == "text"
        ).strip()
    except Exception:
        logger.exception("Claude recommendation request failed")
        return "Sorry, I couldn't reach the AI service just now. Please try again in a moment."
