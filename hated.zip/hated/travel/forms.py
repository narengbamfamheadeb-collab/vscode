from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import ActivityTag, BUDGET_CHOICES, Itinerary, UserProfile


class BootstrapFormMixin:
    """Adds Bootstrap classes to every field's widget automatically."""

    def _style_fields(self):
        for name, field in self.fields.items():
            widget = field.widget
            existing = widget.attrs.get('class', '')
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs['class'] = (existing + ' form-check-input').strip()
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                widget.attrs['class'] = (existing + ' form-select').strip()
            elif isinstance(widget, forms.CheckboxSelectMultiple):
                pass  # styled per-item in the template
            else:
                widget.attrs['class'] = (existing + ' form-control').strip()


class SignUpForm(BootstrapFormMixin, UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style_fields()


class ProfileForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['bio', 'home_city', 'preferred_budget', 'preferred_group_size', 'interests']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3}),
            'interests': forms.CheckboxSelectMultiple(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style_fields()


class RecommendationForm(BootstrapFormMixin, forms.Form):
    budget = forms.ChoiceField(choices=BUDGET_CHOICES)
    interests = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'e.g. hiking, food, museums'})
    )
    travel_dates = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'e.g. June 2027, or "flexible"'})
    )
    group_size = forms.IntegerField(min_value=1, initial=1)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style_fields()


class ItineraryBuilderForm(BootstrapFormMixin, forms.Form):
    title = forms.CharField(max_length=150)
    destination_name = forms.CharField(
        max_length=120,
        label="Destination",
        widget=forms.TextInput(attrs={'placeholder': 'e.g. Rome, Italy'})
    )
    start_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    end_date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    num_days = forms.IntegerField(min_value=1, max_value=30, initial=3, label="Trip length (days)")
    budget = forms.ChoiceField(choices=BUDGET_CHOICES)
    group_size = forms.IntegerField(min_value=1, initial=1)
    interests = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'e.g. art, nightlife, relaxing'})
    )
    use_ai = forms.BooleanField(
        required=False, initial=True, label="Generate day-by-day plan with AI"
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style_fields()


class ChatMessageForm(BootstrapFormMixin, forms.Form):
    message = forms.CharField(
        widget=forms.TextInput(attrs={
            'placeholder': 'Ask about destinations, budgets, packing, itineraries…',
            'autocomplete': 'off',
        })
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style_fields()
