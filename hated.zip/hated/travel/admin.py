from django.contrib import admin

from .models import (
    ActivityTag,
    ChatMessage,
    Destination,
    Itinerary,
    ItineraryActivity,
    ItineraryDay,
    UserProfile,
)


@admin.register(Destination)
class DestinationAdmin(admin.ModelAdmin):
    list_display = ('name', 'country', 'budget_level', 'best_season', 'avg_cost_per_day')
    list_filter = ('budget_level', 'best_season', 'country')
    search_fields = ('name', 'country', 'description')
    filter_horizontal = ('activity_tags',)


@admin.register(ActivityTag)
class ActivityTagAdmin(admin.ModelAdmin):
    search_fields = ('name',)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'home_city', 'preferred_budget', 'preferred_group_size')
    filter_horizontal = ('interests', 'favorite_destinations')


class ItineraryActivityInline(admin.TabularInline):
    model = ItineraryActivity
    extra = 1


class ItineraryDayInline(admin.StackedInline):
    model = ItineraryDay
    extra = 1


@admin.register(Itinerary)
class ItineraryAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'destination', 'start_date', 'end_date', 'is_ai_generated')
    list_filter = ('is_ai_generated', 'budget')
    inlines = [ItineraryDayInline]


@admin.register(ItineraryDay)
class ItineraryDayAdmin(admin.ModelAdmin):
    list_display = ('itinerary', 'day_number', 'summary')
    inlines = [ItineraryActivityInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'created_at')
    list_filter = ('role',)
