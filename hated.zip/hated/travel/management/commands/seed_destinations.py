from django.core.management.base import BaseCommand

from travel.models import ActivityTag, Destination

SAMPLE_TAGS = [
    "Hiking", "Beaches", "Museums", "Nightlife", "Food & Drink",
    "Adventure", "Relaxation", "History", "Wildlife", "Shopping",
]

SAMPLE_DESTINATIONS = [
    dict(name="Lisbon", country="Portugal", budget_level="budget", best_season="spring",
         avg_cost_per_day=70, tags=["Food & Drink", "History", "Nightlife"],
         description="Sun-soaked hills, pastel tiles, and some of Europe's best-value food."),
    dict(name="Kyoto", country="Japan", budget_level="mid", best_season="autumn",
         avg_cost_per_day=110, tags=["History", "Museums", "Food & Drink"],
         description="Centuries of temples, gardens, and quiet ritual amid a modern city."),
    dict(name="Bali", country="Indonesia", budget_level="budget", best_season="summer",
         avg_cost_per_day=55, tags=["Beaches", "Relaxation", "Adventure"],
         description="Rice terraces, surf breaks, and a famously relaxed pace of life."),
    dict(name="Reykjavik", country="Iceland", budget_level="luxury", best_season="summer",
         avg_cost_per_day=180, tags=["Adventure", "Wildlife", "Hiking"],
         description="Glaciers, waterfalls, and the midnight sun — a base for epic road trips."),
    dict(name="Cape Town", country="South Africa", budget_level="mid", best_season="spring",
         avg_cost_per_day=90, tags=["Hiking", "Wildlife", "Food & Drink"],
         description="Table Mountain, wine country, and coastline in one compact city."),
    dict(name="Mexico City", country="Mexico", budget_level="budget", best_season="winter",
         avg_cost_per_day=65, tags=["Museums", "Food & Drink", "Nightlife"],
         description="World-class museums and street food in a sprawling cultural capital."),
    dict(name="Queenstown", country="New Zealand", budget_level="luxury", best_season="summer",
         avg_cost_per_day=150, tags=["Adventure", "Hiking", "Relaxation"],
         description="Alpine lakes and adrenaline sports against a dramatic mountain backdrop."),
    dict(name="Marrakech", country="Morocco", budget_level="budget", best_season="autumn",
         avg_cost_per_day=60, tags=["Shopping", "History", "Food & Drink"],
         description="Maze-like souks, riads, and desert day trips just outside the city."),
    dict(name="Santorini", country="Greece", budget_level="luxury", best_season="summer",
         avg_cost_per_day=200, tags=["Beaches", "Relaxation", "Food & Drink"],
         description="Whitewashed clifftop towns overlooking the Aegean caldera."),
]


class Command(BaseCommand):
    help = "Seed the database with sample activity tags and destinations for local development."

    def handle(self, *args, **options):
        tag_objs = {}
        for name in SAMPLE_TAGS:
            tag, _ = ActivityTag.objects.get_or_create(name=name)
            tag_objs[name] = tag

        created_count = 0
        for entry in SAMPLE_DESTINATIONS:
            dest, created = Destination.objects.get_or_create(
                name=entry["name"],
                defaults=dict(
                    country=entry["country"],
                    description=entry["description"],
                    budget_level=entry["budget_level"],
                    best_season=entry["best_season"],
                    avg_cost_per_day=entry["avg_cost_per_day"],
                ),
            )
            dest.activity_tags.set([tag_objs[t] for t in entry["tags"]])
            if created:
                created_count += 1

        self.stdout.write(self.style.SUCCESS(
            f"Seeded {len(SAMPLE_TAGS)} activity tags and {created_count} new destinations "
            f"({len(SAMPLE_DESTINATIONS)} total defined)."
        ))
