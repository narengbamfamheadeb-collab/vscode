# Voyagent — AI-Powered Travel Partner

A mobile-responsive Django web app for tourists: AI destination
recommendations, a travel chat assistant, a day-by-day itinerary
builder, destination discovery with search/filter, and user profiles
with saved trips and favorites.

Project folder (as opened in VS Code): **`hated`**
Main app: **`travel`** — its `views.py` contains the `index` view that
renders the homepage.

---

## 1. Environment setup

Requires **Python 3.14.7** (or any modern Python 3.11+; the code has no
version-specific syntax).

```bash
# from inside the `hated` project folder
python3 -m venv venv

# activate it
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate           # Windows (cmd/PowerShell)

# install dependencies
pip install -r requirements.txt
```

`requirements.txt` installs:
- `Django` — web framework
- `anthropic` — official Claude API SDK (used by `travel/ai_service.py`)
- `python-dotenv` — loads `.env` automatically if present

## 2. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and set:
- `DJANGO_SECRET_KEY` — any random string for local dev
- `ANTHROPIC_API_KEY` — your key from https://console.anthropic.com/ (optional — see below)

**No API key? No problem.** If `ANTHROPIC_API_KEY` is left blank, the AI
recommendation engine, chat assistant, and itinerary generator all fall
back to clearly-labeled demo/mock responses, so the whole site still
runs and is fully clickable without any external calls.

## 3. Set up the database

```bash
python manage.py makemigrations
python manage.py migrate
```

Create an admin account (used to add destinations via `/admin/`):

```bash
python manage.py createsuperuser
```

Optional — populate the Destination Discovery page with sample data:

```bash
python manage.py seed_destinations
```

## 4. Run the development server

```bash
python manage.py runserver
```

Visit **http://127.0.0.1:8000/**.

---

## Project structure

```
hated/
├── manage.py
├── requirements.txt
├── .env.example
├── hated/                     # project settings package
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py / asgi.py
└── travel/                    # main app
    ├── models.py              # Destination, UserProfile, Itinerary, ItineraryDay,
    │                          # ItineraryActivity, ActivityTag, ChatMessage
    ├── views.py               # index view + all page views
    ├── urls.py
    ├── forms.py
    ├── ai_service.py          # Claude API integration (chat + itinerary + recs)
    ├── admin.py
    ├── signals.py             # auto-creates a UserProfile per new User
    ├── management/commands/seed_destinations.py
    ├── templates/travel/      # all HTML templates (Bootstrap 5, mobile-first)
    └── static/travel/         # css/js
```

## Core features & where to find them

| Feature | URL | Code |
|---|---|---|
| Homepage | `/` | `travel.views.index` |
| Sign up / Login / Logout | `/signup/`, `/login/`, `/logout/` | Django auth + `SignUpForm` |
| Destination discovery + search/filter | `/destinations/` | `views.destinations` |
| Destination detail | `/destinations/<id>/` | `views.destination_detail` |
| AI recommendation engine | `/recommend/` | `views.recommend` → `ai_service.generate_recommendations` |
| AI chat assistant | `/chat/` | `views.chat` → `ai_service.get_chat_reply` |
| Itinerary builder (AI or manual) | `/itineraries/new/` | `views.itinerary_builder` → `ai_service.generate_itinerary` |
| My itineraries / day-by-day plan | `/itineraries/` | `views.my_itineraries`, `views.itinerary_detail` |
| Profile & preferences, favorites | `/profile/` | `views.profile`, `views.toggle_favorite` |

## Notes on the AI integration

`travel/ai_service.py` is the single place that talks to the Claude
API (via the official `anthropic` Python SDK). It exposes three plain
functions used by the views:

- `get_chat_reply(message, history)` — conversational replies for `/chat/`
- `generate_recommendations(budget, interests, travel_dates, group_size)` — text recommendations for `/recommend/`
- `generate_itinerary(destination_name, num_days, budget, interests, group_size)` — asks Claude for **structured JSON** (day-by-day activities), which is then saved into `ItineraryDay` / `ItineraryActivity` rows

All three gracefully fall back to mock/demo content if no API key is
configured or if the API call fails, so the app never crashes for a
missing key — it just tells the user it's in demo mode.

## Mobile-responsive design

Templates use Bootstrap 5's grid and components mobile-first (stacked
single-column on phones, multi-column on tablets/desktops), a
collapsible navbar, and custom CSS (`travel/static/travel/css/style.css`)
with a small `@media (max-width: 576px)` block for phone-specific tweaks.

## Running tests / checks

```bash
python manage.py check
python manage.py test
```

## Deploying

Before deploying anywhere public:
- Set `DJANGO_DEBUG=False`
- Set a strong, secret `DJANGO_SECRET_KEY`
- Set `DJANGO_ALLOWED_HOSTS` to your real domain(s)
- Swap SQLite for Postgres/MySQL in `DATABASES` for production use
- Run `python manage.py collectstatic`
