"""WSGI config for the hated project."""
import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hated.settings')
application = get_wsgi_application()
